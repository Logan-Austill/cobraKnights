"""Fast double-click startup: standard library only; no package installation."""
import fcntl
import json
import os
from pathlib import Path
import secrets
import socket
import subprocess
import sys
import time
from urllib.request import Request,build_opener,ProxyHandler

ROOT=Path(__file__).resolve().parent
RUNTIME=Path.home()/'Library/Application Support/LaneVision Playback'


def dialog(message):
    subprocess.run(['/usr/bin/osascript','-e','on run argv\ndisplay dialog (item 1 of argv) with title "LaneVision Playback" buttons {"OK"} default button "OK"\nend run',message],check=True)


def adjacent():
    bundle=next((p for p in ROOT.parents if p.suffix=='.app'),None)
    return bundle.parent if bundle else ROOT


def status(state):
    req=Request(state['url']+'/api/status',headers={'X-API-Key':state['key']})
    with build_opener(ProxyHandler({})).open(req,timeout=2) as response:return json.load(response)


def open_browser(state):
    subprocess.run(['/usr/bin/open',state['url']+'/#key='+state['key']],check=True)


def main():
    os.umask(0o077);RUNTIME.mkdir(parents=True,exist_ok=True)
    with (RUNTIME/'launch.lock').open('w') as lock:
        try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError:return
        saved=RUNTIME/'session.json'
        if saved.exists():
            try:
                state=json.loads(saved.read_text())
                if status(state).get('app')=='lanevision-playback-1':open_browser(state);return
            except Exception:pass
        folder=adjacent()/'data'
        if not folder.is_dir():
            # A translocated app cannot see its siblings: ask for the data folder
            # rather than silently use the wrong empty directory.
            result=subprocess.run(['/usr/bin/osascript','-e','POSIX path of (choose folder with prompt "Choose the folder containing your downloaded JSON and images")'],capture_output=True,text=True)
            if result.returncode:return
            folder=Path(result.stdout.strip())
        model=next((p for p in (adjacent()/'best.pt',ROOT/'best.pt') if p.is_file()),None)
        with socket.socket() as probe:probe.bind(('127.0.0.1',0));port=probe.getsockname()[1]
        state={'url':'http://127.0.0.1:'+str(port),'key':secrets.token_urlsafe(32)}
        command=[sys.executable,str(ROOT/'server.py'),'--data',str(folder),'--cache',str(RUNTIME/'cache'),'--port',str(port)]
        if model:command+=['--model',str(model)]
        with (RUNTIME/'server.log').open('a') as log:
            process=subprocess.Popen(command,cwd=ROOT,env=dict(os.environ,PLAYBACK_KEY=state['key']),stdin=subprocess.DEVNULL,stdout=log,stderr=log,start_new_session=True)
        state['pid']=process.pid
        for _ in range(100):
            if process.poll() is not None:raise RuntimeError('Playback could not start. See '+str(RUNTIME/'server.log'))
            try:status(state);break
            except Exception:time.sleep(.1)
        else:
            process.terminate();raise RuntimeError('Playback startup timed out. Check server.log.')
        saved.write_text(json.dumps(state));open_browser(state)

if __name__=='__main__':
    try:main()
    except Exception as exc:dialog(str(exc))
