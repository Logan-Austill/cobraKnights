#!/bin/bash
set -eu
cd "$(dirname "$0")"
# Reuse already-installed detection dependencies when available; never install at launch.
for candidate in "$HOME/Library/Application Support/LaneVision Demo/.venv/bin/python" /opt/anaconda3/bin/python /Library/Frameworks/Python.framework/Versions/3.11/bin/python3 /opt/homebrew/bin/python3; do
  if [ -x "$candidate" ] && "$candidate" -c 'import importlib.util,sys; sys.exit(0 if sys.version_info >= (3,9) and all(importlib.util.find_spec(m) for m in ("ultralytics","torch","PIL")) else 1)' >/dev/null 2>&1; then
    exec "$candidate" "${1:-launch.py}"
  fi
done
for candidate in /Library/Frameworks/Python.framework/Versions/3.11/bin/python3 /opt/anaconda3/bin/python /opt/homebrew/bin/python3 /usr/bin/python3; do
  if [ -x "$candidate" ] && "$candidate" -c 'import sys; sys.exit(0 if sys.version_info >= (3,9) else 1)' >/dev/null 2>&1; then
    exec "$candidate" "${1:-launch.py}"
  fi
done
/usr/bin/osascript -e 'display dialog "Install Python 3.9 or newer using a Mac installer, then reopen Start Playback." with title "LaneVision Playback" buttons {"OK"}'
