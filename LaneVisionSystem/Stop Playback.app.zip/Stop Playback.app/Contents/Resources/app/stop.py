import json
import os
import signal
from launch import RUNTIME,status,dialog
try:
    path=RUNTIME/'session.json'
    state=json.loads(path.read_text())
    if status(state).get('app')=='lanevision-playback-1':
        os.kill(state['pid'],signal.SIGTERM);path.unlink();dialog('Playback stopped.')
except Exception:dialog('No running playback server was found.')
