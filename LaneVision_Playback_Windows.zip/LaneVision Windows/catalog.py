"""Read local metadata; prefer its Blob image URLs. No metadata API requests."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
from urllib.parse import urlsplit


def interval_seconds(previous, following):
    return max(10.0, following['epoch']-previous['epoch'])


def safe_file(path, base, root):
    candidate=(base/str(path)).resolve()
    if candidate!=root and root not in candidate.parents:
        raise ValueError('Image path must be inside the data folder')
    if not candidate.is_file(): raise ValueError('Local image is missing')
    return candidate


def load_catalog(folder):
    root=Path(folder).resolve(); records=[]; errors=[]; seen=set()
    by_name={}
    for image in root.rglob('*'):
        if image.is_file() and image.suffix.lower() in ('.jpg','.jpeg','.png'):
            by_name.setdefault(image.name,[]).append(image)
    for file in sorted(root.rglob('*.json')):
        try:
            if file.stat().st_size>20*1024*1024: raise ValueError('JSON exceeds 20 MiB')
            items=json.loads(file.read_text(encoding='utf-8-sig'))
            if isinstance(items,dict): items=items.get('images')
            if not isinstance(items,list): raise ValueError('Expected an array or an object containing images')
        except (OSError,ValueError) as exc:
            errors.append(file.name+': unreadable or invalid JSON array');continue
        for n,item in enumerate(items,1):
            try:
                if not isinstance(item,dict): raise ValueError()
                site=item.get('siteId',item.get('site_id')); camera=item.get('cameraId',item.get('camera_id'))
                if site is None or camera is None: raise ValueError()
                field=next((k for k in ('captured_at','capturedAt','timestamp','lastModified') if item.get(k)),None)
                if field is None: raise ValueError()
                dt=datetime.fromisoformat(str(item[field]).replace('Z','+00:00'))
                if dt.tzinfo is None: raise ValueError()
                epoch=dt.timestamp();stamp=dt.astimezone(timezone.utc).isoformat()
                local=None;url=item.get('url')
                explicit=item.get('image_path') or item.get('path')
                if url:
                    parsed=urlsplit(url)
                    if parsed.scheme!='https' or parsed.netloc!='siteproicebox.blob.core.windows.net' or parsed.fragment or not parsed.path.startswith('/cameraimages/'):
                        raise ValueError('Unsupported image URL')
                elif explicit:
                    local=safe_file(explicit,file.parent,root)
                else:
                    name=Path(str(item.get('name',''))).name
                    for candidate in ([file.parent/'images'/name,file.parent/name,root/'images'/name] if name else []):
                        if candidate.is_file():
                            local=safe_file(candidate,file.parent,root);break
                    if local is None:
                        # JSON may retain an old Blob URL. Use only its basename
                        # for local matching; never make a network request.
                        name=name or Path(urlsplit(str(item.get('url',''))).path).name
                        matches=by_name.get(name,[])
                        if len(matches)>1:
                            matches=[p for p in matches if str(site) in p.parts and str(camera) in p.parts]
                        if len(matches)!=1: raise ValueError('Missing or ambiguous local image')
                        local=safe_file(matches[0],file.parent,root)
                source=str(local) if local else urlsplit(url)._replace(query='').geturl()
                identity=json.dumps([str(site),str(camera),stamp,source]+([local.stat().st_mtime_ns,local.stat().st_size] if local else []))
                fid=hashlib.sha256(identity.encode()).hexdigest()
                if fid in seen: continue
                seen.add(fid)
                records.append({'id':fid,'site':str(site),'camera':str(camera),'timestamp':stamp,
                    'epoch':epoch,'timestamp_source':'storage_last_modified' if field=='lastModified' else 'capture',
                    'name':str(item.get('name') or (local.name if local else Path(urlsplit(url).path).name)),
                    '_local':str(local) if local else None,'_url':url})
            except (ValueError,TypeError,OverflowError,OSError):
                errors.append('{} record {}: missing/invalid site, camera, timestamp or image reference'.format(file.name,n))
    records.sort(key=lambda r:(r['epoch'],r['site'],r['camera'],r['id']))
    return records,errors


def public_record(row):
    return {k:v for k,v in row.items() if not k.startswith('_')}
