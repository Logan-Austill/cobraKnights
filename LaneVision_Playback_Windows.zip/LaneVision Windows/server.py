"""Local-only playback server using Python's standard library.
Optional inference loads in the background; it never delays opening the UI.
"""
import argparse
from datetime import date
from concurrent.futures import ThreadPoolExecutor
import hashlib
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
import json
from pathlib import Path
import secrets
import ssl
from urllib.error import HTTPError, URLError
import threading
from urllib.parse import urlsplit
from urllib.request import build_opener, ProxyHandler, HTTPRedirectHandler, HTTPSHandler

from runtime_version import fingerprint
from catalog import load_catalog,public_record
from lanes import validate_lanes,read_regions,save_regions,occupancy
ROOT=Path(__file__).resolve().parent
LIMIT=10*1024*1024
SERVER_VERSION=fingerprint(ROOT)

def image_error(exc):
    # Never expose signed URLs, tokens, or arbitrary exception text.
    if isinstance(exc, HTTPError):
        if exc.code in (401,403): return 'Image server denied access (HTTP %s).' % exc.code
        if exc.code == 404: return 'Image URL was not found (HTTP 404).'
        return 'Image server returned HTTP %s.' % exc.code
    reason = exc.reason if isinstance(exc, URLError) else exc
    if isinstance(reason, ssl.SSLCertVerificationError):
        return 'Python could not verify the image server HTTPS certificate.'
    if isinstance(reason, TimeoutError): return 'Image download timed out. Try Refresh images.'
    if isinstance(exc, URLError): return 'Python could not connect to the image server. Check network or proxy settings.'
    if isinstance(exc, ValueError): return 'Image response was not a supported JPEG/PNG or exceeded 10 MiB.'
    if isinstance(exc, OSError): return 'Could not read or save the image. Check local cache permissions and free disk space.'
    return 'Could not load image due to an internal error.'

def image_tls_context():
    # Keep system trust and hostname verification; supplement missing Python roots.
    context = ssl.create_default_context()
    bundle = ROOT / 'cacert.pem'
    if bundle.is_file():
        context.load_verify_locations(cafile=str(bundle))
    else:
        try:
            import certifi
        except ImportError:
            pass
        else:
            context.load_verify_locations(cafile=certifi.where())
    return context

class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self,*args,**kwargs): return None

class Playback:
    def __init__(self,data,cache,model=None):
        self.data=Path(data);self.cache=Path(cache);self.cache.mkdir(parents=True,exist_ok=True)
        self.lock=threading.RLock();self.download_lock=threading.Lock()
        self.records={};self.rows=[];self.errors=[];self.results={}
        self.engine=None;self.model_message='Truck detection unavailable; images will still play.'
        self.worker=ThreadPoolExecutor(max_workers=1)
        self.reload()
        if model and Path(model).is_file(): self.worker.submit(self.load_model,model)
        else: self.model_message='No best.pt found. Playing images without truck counts.'

    def reload(self):
        rows,errors=load_catalog(self.data)
        with self.lock:
            self.rows=rows;self.records={row['id']:row for row in rows};self.errors=errors
        return self.manifest()

    def get_lanes(self):
        with self.lock:return read_regions(self.data.parent/'lane_regions.json')

    def set_lanes(self,body):
        if not isinstance(body,dict):raise ValueError('Invalid request.')
        site,camera=body.get('site'),body.get('camera')
        if not isinstance(site,str) or not isinstance(camera,str):raise ValueError('Select a site and camera.')
        lanes=validate_lanes(body.get('lanes'))
        with self.lock:
            if not any(r['site']==site and r['camera']==camera for r in self.rows):
                raise ValueError('Unknown site or camera.')
            path=self.data.parent/'lane_regions.json';data=read_regions(path)
            data.setdefault(site,{})[camera]={'lanes':lanes}
            save_regions(path,data)
        return {'saved':True,'count':len(lanes)}

    def lane_config(self):
        path=self.data.parent/'lane_config.json'
        if not path.exists(): return {}, None
        try:
            config=json.loads(path.read_text())
            if not isinstance(config,dict): raise ValueError()
            for cameras in config.values():
                if not isinstance(cameras,dict): raise ValueError()
                for total in cameras.values():
                    if total is not None and (type(total) is not int or total<0): raise ValueError()
            return config, None
        except (OSError,ValueError):
            return {}, 'Lane configuration invalid: use site IDs, camera IDs, and nonnegative whole numbers or null.'

    def demo_config(self):
        path=self.data.parent/'demo_config.json'
        if not path.exists():return {'demo_date':None},None
        try:
            config=json.loads(path.read_text())
            value=config.get('demo_date')
            if value is not None:
                if not isinstance(value,str) or date.fromisoformat(value).isoformat()!=value:raise ValueError()
            return {'demo_date':value},None
        except (OSError,ValueError,AttributeError,TypeError):
            return {'demo_date':None},'Invalid demo_config.json. Use a YYYY-MM-DD demo_date or null.'

    def manifest(self):
        lanes,lane_error=self.lane_config()
        demo,demo_error=self.demo_config()
        with self.lock:
            return {'demo':demo,'demo_error':demo_error,'lanes':lanes,'lane_error':lane_error,'frames':[public_record(r) for r in self.rows], 'errors':self.errors[:100],
                'error_count':len(self.errors),'model_ready':self.engine is not None,
                'model_message':self.model_message,'data_folder':str(self.data)}

    def load_model(self,path):
        self.model_message='Loading truck detector in the background…'
        try:
            from detector import load_detector
            engine=load_detector(path,'Water-Hauling Truck',.25,'cpu')
            with self.lock: self.engine=engine;self.model_message='Truck detector ready'
        except Exception:
            self.model_message='Detection unavailable: this Python needs compatible PyTorch/Ultralytics and a valid truck checkpoint. Playback still works.'

    def image(self,fid):
        row=self.records[fid]
        if row.get('_url'):
            # Images only: no company API, token, password, cookies or redirects.
            # Signed query strings are preserved, never shown in the UI or logs.
            with self.download_lock:
                cached=self.cache/(fid+'.image')
                if cached.is_file():return cached.read_bytes()
                with build_opener(ProxyHandler({}),NoRedirect(),HTTPSHandler(context=image_tls_context())).open(row['_url'],timeout=20) as response:
                    data=response.read(LIMIT+1)
                self.validate_image(data)
                temporary=cached.with_suffix('.partial');temporary.write_bytes(data);temporary.replace(cached)
                files=sorted(self.cache.glob('*.image'),key=lambda p:p.stat().st_mtime,reverse=True)
                total=0
                for file in files:
                    total+=file.stat().st_size
                    if total>256*1024*1024:file.unlink()
                return data
        path=Path(row['_local'])
        if path.stat().st_size>LIMIT: raise ValueError('Image exceeds 10 MiB')
        data=path.read_bytes();self.validate_image(data);return data

    @staticmethod
    def validate_image(data):
        if len(data)>LIMIT:raise ValueError('Image exceeds 10 MiB')
        if not (data.startswith(b'\xff\xd8\xff') or data.startswith(b'\x89PNG\r\n\x1a\n')):
            raise ValueError('Expected JPEG or PNG bytes')

    def detection(self,fid):
        if fid not in self.records: raise KeyError(fid)
        with self.lock:
            if fid in self.results:
                cached=self.results[fid]
                if cached.get('state')!='ready':return cached
                row=self.records[fid];result=dict(cached['result'])
                try:
                    regions=self.get_lanes().get(row['site'],{}).get(row['camera'],{}).get('lanes',[])
                    config,error=self.lane_config()
                    result['occupancy']=occupancy(result,regions,config.get(row['site'],{}).get(row['camera']))
                    if error:result['occupancy']={'status':'Unknown','occupied':None,'total':None,'lanes':[],'message':error}
                except (ValueError, OSError, TypeError, AttributeError):
                    result['occupancy']={'status':'Unknown','occupied':None,'total':None,'lanes':[],'message':'Unable to read lane configuration.'}
                return {'state':'ready','result':result}
            if self.engine is None: return {'state':'unavailable','message':self.model_message}
            self.results[fid]={'state':'pending'};self.worker.submit(self.analyze,fid)
            return self.results[fid]

    def analyze(self,fid):
        try:
            from detector import decode_image
            image=decode_image(self.image(fid))
            try: result=self.engine.predict(image)
            finally: image.close()
            output={'state':'ready','result':result}
        except Exception: output={'state':'error','message':'Detection failed; count is unknown.'}
        with self.lock:self.results[fid]=output


def make_handler(app,key):
    class Handler(BaseHTTPRequestHandler):
        def log_message(self,*args): pass
        def send(self,status,body,content_type='application/json'):
            if not isinstance(body,bytes):body=json.dumps(body).encode()
            self.send_response(status)
            for name,value in {'Content-Type':content_type,'Content-Length':str(len(body)),
                'Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Referrer-Policy':'no-referrer',
                'Content-Security-Policy':"default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' blob:; connect-src 'self'; frame-ancestors 'none'"}.items():self.send_header(name,value)
            self.end_headers();self.wfile.write(body)
        def do_POST(self):
            port=self.server.server_port
            if self.headers.get('Host') not in ['127.0.0.1:'+str(port),'localhost:'+str(port)] or not secrets.compare_digest(self.headers.get('X-API-Key','').encode(),key.encode()):
                self.send(403,{'error':'Local authenticated access required.'});return
            if urlsplit(self.path).path!='/api/lanes':self.send(404,{'error':'Not found'});return
            try:
                size=int(self.headers.get('Content-Length','0'))
                if not 0<size<=256*1024:raise ValueError('Invalid request size.')
                body=json.loads(self.rfile.read(size))
                self.send(200,app.set_lanes(body))
            except (ValueError,TypeError):self.send(400,{'error':'Invalid lane configuration. Use unique names and at least three distinct corners per lane, without crossing edges.'})
            except OSError:self.send(500,{'error':'Could not save lane configuration. Check folder permissions.'})

        def do_GET(self):
            port=self.server.server_port
            if self.headers.get('Host') not in ['127.0.0.1:'+str(port),'localhost:'+str(port)]:
                self.send(403,{'error':'Local access only'});return
            path=urlsplit(self.path).path
            if path.startswith('/api/') and not secrets.compare_digest(self.headers.get('X-API-Key','').encode(),key.encode()):
                self.send(401,{'error':'Reopen Start Playback to connect.'});return
            try:
                if path=='/api/manifest':self.send(200,app.manifest())
                elif path=='/api/reload':self.send(200,app.reload())
                elif path=='/api/lanes':self.send(200,app.get_lanes())
                elif path=='/api/status':self.send(200,{'app':'lanevision-playback-1','version':SERVER_VERSION,'root':str(ROOT)})
                elif path.startswith('/api/image/'):
                    data=app.image(path.rsplit('/',1)[1]);self.send(200,data,'image/png' if data.startswith(b'\x89PNG') else 'image/jpeg')
                elif path.startswith('/api/detection/'):self.send(200,app.detection(path.rsplit('/',1)[1]))
                elif path in ['/','/static/playback.js','/static/timing.js','/static/lane_editor.js','/static/login.js','/static/sitepro_logo.png']:
                    file=ROOT/'static'/({'/':'site_activity.html'}.get(path,path.rsplit('/',1)[1]))
                    self.send(200,file.read_bytes(),'text/html; charset=utf-8' if path=='/' else 'image/png' if path.endswith('.png') else 'text/javascript; charset=utf-8')
                else:self.send(404,{'error':'Not found'})
            except KeyError:self.send(404,{'error':'Image not found; reload metadata'})
            except Exception as exc:self.send(502,{'error':image_error(exc)})
    return Handler

if __name__=='__main__':
    import os
    parser=argparse.ArgumentParser();parser.add_argument('--data',required=True);parser.add_argument('--cache',required=True)
    parser.add_argument('--port',type=int,required=True);parser.add_argument('--model');args=parser.parse_args()
    app=Playback(args.data,args.cache,args.model)
    ThreadingHTTPServer(('127.0.0.1',args.port),make_handler(app,os.environ['PLAYBACK_KEY'])).serve_forever()
