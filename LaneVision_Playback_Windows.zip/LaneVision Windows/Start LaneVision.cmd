@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
 echo Run Setup Windows.cmd first.
 pause
 exit /b 1
)
".venv\Scripts\python.exe" launch_windows.py
if errorlevel 1 pause
