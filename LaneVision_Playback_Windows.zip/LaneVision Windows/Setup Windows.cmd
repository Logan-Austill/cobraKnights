@echo off
setlocal
cd /d "%~dp0"
echo Setting up LaneVision. First setup requires internet and may take several minutes.
py -3.11 -c "import sys; assert sys.maxsize > 2**32" >nul 2>&1
if errorlevel 1 (
 echo Install Python 3.11 64-bit from python.org, including the Python launcher.
 echo Then double-click Setup Windows.cmd again.
 pause
 exit /b 1
)
if not exist ".venv\Scripts\python.exe" (
 py -3.11 -m venv .venv
 if errorlevel 1 goto failed
)
".venv\Scripts\python.exe" -m pip install --upgrade pip
if errorlevel 1 goto failed
".venv\Scripts\python.exe" -m pip install -r requirements-windows.txt
if errorlevel 1 goto failed
".venv\Scripts\python.exe" -c "import torch, ultralytics; from PIL import Image"
if errorlevel 1 goto failed
echo Setup complete. Double-click Start LaneVision.cmd.
pause
exit /b 0
:failed
echo Setup failed. Check the error above and your internet connection, then retry.
pause
exit /b 1
