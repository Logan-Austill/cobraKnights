"use strict";
// Presentation-only sign-in: never transmit or persist entered credentials.
$('loginForm').addEventListener('submit',event=>{
  event.preventDefault();
  if(demoSignedIn)return;
  $('username').value='';
  $('password').value='';
  demoSignedIn=true;
  $('loginPage').classList.add('hidden');
  $('dashboard').classList.remove('hidden');
  $('dashboardSidebar').classList.remove('hidden');
  $('siteSearch').focus();
  if(key)load('initial');else notice('Open the LaneVision app to connect to the dashboard.');
});
