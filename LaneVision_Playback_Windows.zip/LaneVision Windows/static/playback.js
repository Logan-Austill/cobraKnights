'use strict';
const $=id=>document.getElementById(id);
const key=new URLSearchParams(location.hash.slice(1)).get('key')||'';
history.replaceState(null,'',location.pathname);
let demoSignedIn=false,demoDate=null,demoConfigInvalid=false;
function timelineNow(){return PlaybackTiming.replayNow(Date.now(),demoDate)/1000;}
let frames=[],playlist=[],current=null,index=-1,siteFilter=null,cameraFilter='',filter='all';
let generation=0,objectURL=null,detectionTimer=null,loading=false,displayedAt=0;
let laneConfig={};
const waitTimers=new Map(),siteCameraResults=new Map();
let siteCheckBusy=false;
let synchronizedTime=null,browsing=false;
let plannedId=null,refreshBusy=false,refreshQueued=false;
const latest=new Map(),counts=new Map(),clock=new PlaybackTiming.PlaybackClock();
const format=s=>new Date(s).toLocaleTimeString(undefined,{hour:'numeric',minute:'2-digit',second:'2-digit',timeZoneName:'short'});
function imageTime(stamp){const date=new Date(stamp),today=new Date(Date.now());return date.toDateString()===today.toDateString()?format(stamp):`${date.toLocaleDateString()} · ${format(stamp)}`;}
function updateCurrentTime(){
  $('currentTime').textContent=format(Date.now());
  $('demoTimeline').textContent=demoConfigInvalid?'Demo configuration needs correction':demoDate?`Recorded demo · ${demoDate} · ${format(timelineNow()*1000)}`:'';
  if(current&&current.epoch>timelineNow()){browsing=false;resetView();planNext();}
  if(current){$('lastUpdated').textContent=format(current.timestamp);$('frameInfo').textContent=`Camera ${current.camera} · Image timestamp: ${imageTime(current.timestamp)}`;}
  navigation();
  if(demoSignedIn&&!demoConfigInvalid)planNext();
}
updateCurrentTime();setInterval(updateCurrentTime,1000);
async function api(path){const r=await fetch(path,{headers:{'X-API-Key':key}});if(!r.ok){let data;try{data=await r.json();}catch{}throw new Error(data?.error||`Request failed (${r.status})`);}return r;}
async function json(path){return (await api(path)).json();}
function notice(text){$('playbackNotice').textContent=text;}
function stat(label,value){const el=document.createElement('span');el.className='stat';const l=document.createElement('span');l.className='stat-label';l.textContent=label;const v=document.createElement('span');v.className='stat-value';v.textContent=value;if(label==='Status')v.style.color=value==='Full'?'#c62828':value==='Available'?'#14833b':'#666';el.append(l,v);return el;}
function latestCameraFrames(){
  const chosen=new Map();
  for(const frame of frames){
    if(frame.epoch>timelineNow())continue;
    const id=JSON.stringify([frame.site,frame.camera]),previous=chosen.get(id);
    if(!previous||frame.epoch>=previous.epoch)chosen.set(id,frame);
  }
  return [...chosen.values()];
}
function siteStatus(site){
  const cameras=[...new Set(frames.filter(f=>f.site===site).map(f=>f.camera))];
  const latestFrames=latestCameraFrames().filter(f=>f.site===site);
  const statuses=latestFrames.map(f=>siteCameraResults.get(f.id)||'Unknown');
  if(statuses.includes('Full'))return 'Full';
  if(statuses.includes('Available'))return 'Available';
  return 'Unknown';
}
function siteSummary(site){
  const candidates=latestCameraFrames().filter(f=>f.site===site).map(frame=>{
    const result=counts.get(frame.id);
    const total=laneConfig[site]?.[frame.camera]??result?.occupancy?.total??null;
    return {frame,result,total,occupied:result?.occupancy?.occupied??null};
  });
  candidates.sort((a,b)=>(b.total??-1)-(a.total??-1)||(b.occupied??-1)-(a.occupied??-1)||a.frame.camera.localeCompare(b.frame.camera,undefined,{numeric:true}));
  return candidates[0]||null;
}
async function checkSiteCameras(){
  if(siteCheckBusy)return;siteCheckBusy=true;
  try{
    for(const frame of latestCameraFrames()){
      try{
        const data=await json('/api/detection/'+frame.id);
        if(data.state==='ready')counts.set(frame.id,data.result);else counts.delete(frame.id);
        siteCameraResults.set(frame.id,data.state==='ready'?(data.result.occupancy?.status||'Unknown'):'Unknown');
      }catch{siteCameraResults.set(frame.id,'Unknown');counts.delete(frame.id);}
    }
    sites();
  }finally{siteCheckBusy=false;}
}
function sites(){
  $('siteList').replaceChildren();
  for(const site of [...new Set(frames.map(f=>f.site))].sort()){
    const summary=siteSummary(site), status=siteStatus(site);
    if(!site.toLowerCase().includes($('siteSearch').value.toLowerCase())||(filter!=='all'&&status.toLowerCase()!==filter))continue;
    const button=document.createElement('button');button.className='site-card'+(current?.site===site?' selected':'');
    const title=document.createElement('h2');title.textContent=`SiteID ${site}`;
    const stats=document.createElement('div');stats.className='card-stats';
    stats.append(stat('Truck Count',summary?.result?.truck_count??'—'),stat('Lanes in use',`${summary?.occupied??'—'} / ${summary?.total??'—'}`),stat('Status',status));
    const source=document.createElement('div');source.className='playback-caption';source.textContent=summary?`Counts from camera ${summary.frame.camera}`:'';
    button.append(title,stats,source);button.onclick=()=>{siteFilter=site;cameraFilter=summary?.frame.camera||'';selectCamera();};$('siteList').append(button);
  }
  if(!$('siteList').children.length)$('siteList').textContent=frames.length?'No matching sites. Availability requires lane configuration.':'No images available.';
}
function cameras(){
  const ids=[...new Set(frames.filter(f=>f.site===siteFilter).map(f=>f.camera))].sort();
  if(!cameraFilter)cameraFilter=ids[0]||'';
  $('camera').replaceChildren();
  for(const id of ids)$('camera').add(new Option(id,id));
  $('camera').value=cameraFilter;
}
function selection(){return PlaybackTiming.selectedFrames(frames,siteFilter,cameraFilter);}
function resetView(){
  clock.clear();plannedId=null;generation++;clearTimeout(detectionTimer);current=null;loading=false;
  if(objectURL)URL.revokeObjectURL(objectURL);objectURL=null;
  $('frameImage').hidden=true;$('imageMessage').hidden=false;$('imageMessage').textContent='Waiting for images from this camera…';
  $('frameInfo').textContent='';$('detectionInfo').textContent='';$('lastUpdated').textContent='Waiting for data';metrics();
}
async function selectCamera(){
  browsing=false;resetView();cameras();playlist=selection();
  $('detailsSection').classList.add('visible');$('detailSiteTitle').textContent=`SiteID ${siteFilter}`;
  const frame=PlaybackTiming.frameAtTime(playlist,timelineNow());
  if(frame)await show(frame);
  else {displayedAt=performance.now();sites();planNext();}

}
function planNext(){
  if(loading||browsing||demoConfigInvalid)return;
  playlist=selection();const next=PlaybackTiming.frameAtTime(playlist,timelineNow());
  if(!next||next.id===current?.id){clock.clear();plannedId=null;return;}
  if(plannedId===next.id)return;
  clock.clear();plannedId=next.id;
  const due=current?displayedAt+10000:performance.now();
  clock.start(Math.max(0,due-performance.now()),()=>{
    plannedId=null;
    // Recheck wall time and selection: never show a future or stale queued frame.
    const frame=PlaybackTiming.frameAtTime(selection(),timelineNow());
    if(!browsing&&!loading&&!demoConfigInvalid&&frame&&frame.id!==current?.id)show(frame);
  });
  if(document.hidden)clock.pause();
}
function eligibleFrames(){return selection().filter(f=>f.epoch<=timelineNow());}
function navigation(){
  const eligible=eligibleFrames(),i=eligible.findIndex(f=>f.id===current?.id);
  $('previous').disabled=loading||i<=0;
  $('next').disabled=loading||i<0||i>=eligible.length-1;
}
async function browse(direction){
  if(loading)return;
  const eligible=eligibleFrames(),i=eligible.findIndex(f=>f.id===current?.id),frame=eligible[i+direction];
  if(i<0||!frame)return;
  browsing=frame.id!==eligible[eligible.length-1]?.id;clock.clear();plannedId=null;await show(frame);
}
$('previous').onclick=()=>browse(-1);$('next').onclick=()=>browse(1);
function activeWait(){
  if(!siteFilter||!cameraFilter)return null;
  const id=JSON.stringify([siteFilter,cameraFilter]);
  if(!waitTimers.has(id))waitTimers.set(id,new PlaybackTiming.WaitTimer());
  return waitTimers.get(id);
}
function renderWait(){
  const timer=activeWait(), seconds=Math.ceil((timer?.left()??0)/1000);
  $('detailTime').textContent=`${Math.floor(seconds/60)}:${String(seconds%60).padStart(2,'0')}`;
  $('waitStop').textContent=timer&&timer.deadline===null&&seconds>0?'Resume':'Stop';
  $('waitState').textContent=!seconds?'Not started / complete':timer.deadline===null?'Stopped':'Counting down';
  $('waitAdd').disabled=!timer;$('waitStop').disabled=!timer||!seconds;$('waitReset').disabled=!timer||!seconds;
}
$('waitAdd').onclick=()=>{activeWait()?.add();renderWait();};
$('waitStop').onclick=()=>{activeWait()?.toggle();renderWait();};
$('waitReset').onclick=()=>{activeWait()?.reset();renderWait();};
setInterval(renderWait,1000);
function metrics(){
  navigation();
  const result=counts.get(current?.id);$('detailTrucks').textContent=result?.truck_count??'—';
  const occ=result?.occupancy;
  $('detailLanes').textContent=occ?.occupied??'—';$('detailTotal').textContent=occ?.total??laneConfig[siteFilter]?.[cameraFilter]??'—';renderWait();
  const status=occ?.status||'Unknown';$('detailStatus').textContent=status;
  $('detailStatusBox').classList.toggle('unknown',status==='Unknown');
  $('detailStatusBox').style.background=status==='Full'?'#ef5350':status==='Available'?'#0bd827':'#eee';
  $('occupancyInfo').textContent=occ?.message||'Lane occupancy is available after truck detection.';
  draw(result);
}
function draw(result){
  const svg=$('boxes');svg.replaceChildren();if(!result)return;
  svg.setAttribute('viewBox',`0 0 ${result.image_width} ${result.image_height}`);
  for(const lane of result.occupancy?.lanes||[]){
    const polygon=document.createElementNS('http://www.w3.org/2000/svg','polygon');
    const color=lane.occupied===true?'#ef5350':lane.occupied===false?'#00c853':'#ffab00';
    polygon.setAttribute('points',lane.points.map(([x,y])=>`${x*result.image_width},${y*result.image_height}`).join(' '));
    polygon.setAttribute('fill',color+'33');polygon.setAttribute('stroke',color);polygon.setAttribute('stroke-width',Math.max(2,result.image_width/400));svg.append(polygon);
  }
  for(const box of result.detections){const [x1,y1,x2,y2]=box.box_xyxy,rect=document.createElementNS('http://www.w3.org/2000/svg','rect');
    for(const [k,v] of Object.entries({x:x1,y:y1,width:x2-x1,height:y2-y1,fill:'none',stroke:'#08bf27','stroke-width':Math.max(2,result.image_width/400)}))rect.setAttribute(k,v);svg.append(rect);}
}
async function detect(frame,token){
  if(token!==generation)return;
  try{const data=await json('/api/detection/'+frame.id);if(token!==generation)return;
    if(data.state==='ready'){counts.set(frame.id,data.result);siteCameraResults.set(frame.id,data.result.occupancy?.status||'Unknown');$('detectionInfo').textContent='Water-hauling truck detections in this image';metrics();sites();detectionTimer=setTimeout(()=>detect(frame,token),5000);}
    else if(data.state==='pending'||data.state==='unavailable'){$('detectionInfo').textContent=data.state==='pending'?'Detecting trucks…':'Truck count currently unavailable.';detectionTimer=setTimeout(()=>detect(frame,token),1500);}
    else $('detectionInfo').textContent=data.message;
  }catch(e){if(token===generation)$('detectionInfo').textContent='Truck count unavailable.';}
}
async function show(frame,referenceTime=timelineNow()){
  if(!frame||frame.epoch>timelineNow()||frame.site!==siteFilter||frame.camera!==cameraFilter)return;
  clock.clear();plannedId=null;clearTimeout(detectionTimer);const token=++generation;current=frame;synchronizedTime=referenceTime;
  loading=true;$('frameImage').hidden=true;$('imageMessage').hidden=false;$('imageMessage').textContent='Loading image…';
  if(objectURL)URL.revokeObjectURL(objectURL);objectURL=null;
  $('detailsSection').classList.add('visible');$('detailSiteTitle').textContent=`SiteID ${frame.site}`;
  $('frameInfo').textContent=`Camera ${frame.camera} · Image timestamp: ${imageTime(frame.timestamp)}`;
  $('lastUpdated').textContent=format(frame.timestamp);
  $('detectionInfo').textContent='';metrics();
  try{
    const response=await api('/api/image/'+frame.id);const blob=await response.blob();if(token!==generation)return;
    objectURL=URL.createObjectURL(blob);
    const image=$('frameImage');image.src=objectURL;await image.decode();if(token!==generation)return;
    if(frame.epoch>timelineNow()){browsing=false;resetView();planNext();return;}
    image.hidden=false;$('imageMessage').hidden=true;latest.set(frame.site,frame.id);sites();detect(frame,token);
  }catch(e){if(token!==generation)return;console.warn('Image load failed',e);$('imageMessage').textContent=e.message||'The browser could not display this image.';$('detectionInfo').textContent='Image unavailable; count is unknown.';}
  if(token!==generation)return;loading=false;metrics();
  displayedAt=performance.now();planNext();
}
$('camera').onchange=()=>{cameraFilter=$('camera').value;selectCamera();};
$('siteSearch').oninput=sites;
document.querySelectorAll('.filter').forEach(b=>b.onclick=()=>{filter=filter===b.dataset.filter?'all':b.dataset.filter;document.querySelectorAll('.filter').forEach(x=>x.classList.toggle('active',x.dataset.filter===filter));sites();});
let hiddenAt=null;
document.addEventListener('visibilitychange',()=>{
  if(document.hidden){hiddenAt=performance.now();clock.pause();}
  else {if(hiddenAt!==null)displayedAt+=performance.now()-hiddenAt;hiddenAt=null;clock.resume();if(demoSignedIn){planNext();load('auto');}}
});
setInterval(()=>{$('nextInfo').textContent=loading?'Loading image…':browsing?'Browsing history · Refresh images returns to latest':plannedId?`Camera ${cameraFilter} · Updating automatically`:'Waiting for new images…';},500);
async function load(mode='auto'){
  if(!demoSignedIn)return;
  if(refreshBusy){if(mode==='latest')refreshQueued=true;return;}
  refreshBusy=true;
  try{
    const data=await json('/api/reload');
    const replayError=data.demo_error||(!data.demo?'This server is outdated. Close this tab and reopen Start Playback.app.':null);
    const nextDate=data.demo?.demo_date||null,nextInvalid=Boolean(replayError);
    if(nextDate!==demoDate||nextInvalid!==demoConfigInvalid){browsing=false;resetView();}
    demoDate=nextDate;demoConfigInvalid=nextInvalid;
    frames=demoConfigInvalid?[]:data.frames.filter(f=>!demoDate||PlaybackTiming.localDateKey(f.epoch*1000)===demoDate);
    laneConfig=data.lanes||{};updateCurrentTime();metrics();
    notice(replayError||data.lane_error||(data.error_count?'Some images are unavailable.':''));
    if(data.error_count)console.warn('Skipped input records',data.errors);
    if(!siteFilter&&frames.length){siteFilter=frames[0].site;cameraFilter='';cameras();}
    cameras();playlist=selection();sites();checkSiteCameras();
    if(mode==='latest'){
      browsing=false;
      const latestFrame=PlaybackTiming.frameAtTime(playlist,timelineNow());
      if(latestFrame)await show(latestFrame);
      else resetView();
    }else if(!current&&!loading&&playlist.length){
      const frame=PlaybackTiming.frameAtTime(playlist,timelineNow());
      if(frame)await show(frame);else planNext();
    }
    else planNext();
    if(!frames.length){$('detailsSection').classList.add('visible');$('imageMessage').textContent='No images available.';}
  }catch(e){console.warn('Image list unavailable',e);notice('Images are currently unavailable. Please try again.');}
  finally{refreshBusy=false;if(refreshQueued){refreshQueued=false;load('latest');}}
}
$('reload').onclick=()=>load('latest');
// Discover newly added JSON records without resetting the active camera or timer.
setInterval(()=>{if(key)load('auto');},5000);
if(key)load('initial');else notice('Open the LaneVision app to connect to the dashboard.');
