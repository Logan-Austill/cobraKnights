'use strict';
// Editor uses a frozen copy of the visible image, separate from playback.
(()=>{
  const modal=$('laneEditor'),canvas=$('laneCanvas'),ctx=canvas.getContext('2d');
  const snapshot=document.createElement('canvas');
  let lanes=[],points=[],editing=-1,site='',camera='',busy=false;
  function message(text){$('laneEditorMessage').textContent=text;}
  function draw(){
    ctx.clearRect(0,0,canvas.width,canvas.height);ctx.drawImage(snapshot,0,0);
    function polygon(vertices,color,closed,label){
      if(!vertices.length)return;
      ctx.beginPath();vertices.forEach(([x,y],i)=>i?ctx.lineTo(x*canvas.width,y*canvas.height):ctx.moveTo(x*canvas.width,y*canvas.height));
      if(closed){ctx.closePath();ctx.fillStyle=color+'33';ctx.fill();}
      ctx.lineWidth=Math.max(2,canvas.width/400);ctx.strokeStyle=color;ctx.stroke();
      for(const [x,y] of vertices){ctx.beginPath();ctx.arc(x*canvas.width,y*canvas.height,Math.max(3,canvas.width/200),0,Math.PI*2);ctx.fillStyle=color;ctx.fill();}
      if(label){ctx.font=`bold ${Math.max(16,canvas.width/50)}px sans-serif`;ctx.lineWidth=3;ctx.strokeStyle='black';ctx.strokeText(label,vertices[0][0]*canvas.width+8,vertices[0][1]*canvas.height+20);ctx.fillStyle='white';ctx.fillText(label,vertices[0][0]*canvas.width+8,vertices[0][1]*canvas.height+20);}
    }
    lanes.forEach((lane,i)=>{if(i!==editing)polygon(lane.points,'#00c853',true,lane.name);});
    polygon(points,'#ffab00',false,$('laneName').value);
  }
  function clear(){points=[];editing=-1;$('laneName').value=`Lane ${lanes.length+1}`;draw();}
  function list(){
    $('laneList').replaceChildren();
    lanes.forEach((lane,i)=>{
      const row=document.createElement('div'),label=document.createElement('span');label.textContent=lane.name;row.append(label);
      const edit=document.createElement('button');edit.textContent='Redraw';edit.onclick=()=>{editing=i;points=[];$('laneName').value=lane.name;message('Click replacement corners, then Finish lane. Clear drawing keeps the original.');draw();};
      const remove=document.createElement('button');remove.textContent='Delete';remove.onclick=()=>{lanes.splice(i,1);clear();list();};
      row.append(edit,remove);$('laneList').append(row);
    });
  }
  $('configureLanes').onclick=async()=>{
    const image=$('frameImage');
    if(loading||!current||image.hidden||!image.naturalWidth){notice('Wait for an image to load before configuring lanes.');return;}
    site=current.site;camera=current.camera;
    canvas.width=snapshot.width=image.naturalWidth;canvas.height=snapshot.height=image.naturalHeight;
    snapshot.getContext('2d').drawImage(image,0,0);
    lanes=[];points=[];editing=-1;busy=true;$('laneSave').disabled=true;
    $('laneEditorTitle').textContent=`Configure lanes · Site ${site} · Camera ${camera}`;
    modal.showModal();draw();list();message('Loading saved lanes…');
    try{const saved=await json('/api/lanes');lanes=structuredClone(saved[site]?.[camera]?.lanes||[]);clear();list();message('Click corners around a lane, then Finish lane.');$('laneSave').disabled=false;}
    catch(e){message('Could not load saved lanes. Close and try again; existing lanes will not be overwritten.');}
    finally{busy=false;}
  };
  canvas.addEventListener('pointerdown',event=>{
    if(busy||$('laneSave').disabled)return;
    const rect=canvas.getBoundingClientRect();
    points.push([Math.max(0,Math.min(1,(event.clientX-rect.left)/rect.width)),Math.max(0,Math.min(1,(event.clientY-rect.top)/rect.height))]);draw();
  });
  $('laneName').oninput=draw;
  $('laneUndo').onclick=()=>{points.pop();draw();};
  $('laneClear').onclick=clear;
  $('laneFinish').onclick=()=>{
    const name=$('laneName').value.trim();
    if(points.length<3){message('Click at least three corners.');return;}
    if(!name||lanes.some((l,i)=>i!==editing&&l.name===name)){message('Use a unique lane name.');return;}
    const lane={name,points:points.map(p=>[...p])};
    if(editing<0)lanes.push(lane);else lanes[editing]=lane;
    clear();list();message('Lane finished. Draw another lane or Save lanes.');
  };
  $('laneSave').onclick=async()=>{
    if(busy)return;
    if(points.length||editing>=0){message('Finish or clear your current drawing first.');return;}
    busy=true;$('laneSave').disabled=true;
    try{
      const response=await fetch('/api/lanes',{method:'POST',headers:{'X-API-Key':key,'Content-Type':'application/json'},body:JSON.stringify({site,camera,lanes})});
      const result=await response.json();if(!response.ok)throw new Error(result.error||'Save failed.');
      modal.close();notice(`Saved ${lanes.length} lane polygons for camera ${camera}.`);
    }catch(e){message(e.message);}
    finally{busy=false;$('laneSave').disabled=false;}
  };
  $('laneCancel').onclick=()=>{if(!busy)modal.close();};
  modal.addEventListener('cancel',event=>{if(busy)event.preventDefault();});
})();
