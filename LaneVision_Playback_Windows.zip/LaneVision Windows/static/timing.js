// Works in both the browser and Node tests. All durations are milliseconds.
(function(root){
  function localDateKey(value){
    const d=new Date(value);return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
  }
  function replayNow(now,demoDate){
    if(!demoDate)return now;
    const [y,m,d]=demoDate.split('-').map(Number),wall=new Date(now);
    return new Date(y,m-1,d,wall.getHours(),wall.getMinutes(),wall.getSeconds(),wall.getMilliseconds()).getTime();
  }
  function gapMs(previous,next){return Math.max(10000,(next.epoch-previous.epoch)*1000);}
  function selectedFrames(frames,site,camera){return frames.filter(f=>f.site===site&&f.camera===camera);}
  function nextFrame(frames,current){
    if(!current)return frames[0]||null;
    const index=frames.findIndex(f=>f.id===current.id);
    return index>=0?(frames[index+1]||null):(frames.find(f=>f.epoch>current.epoch)||null);
  }
  function latestFrame(frames){return frames[frames.length-1]||null;}
  function frameAtTime(frames,epoch){
    return frames.filter(f=>f.epoch<=epoch).reduce((best,f)=>!best||f.epoch>best.epoch?f:best,null);
  }
  class WaitTimer {
    constructor(now=()=>Date.now()){this.now=now;this.remaining=0;this.deadline=null;}
    left(){return this.deadline===null?this.remaining:Math.max(0,this.deadline-this.now());}
    add(){const paused=this.deadline===null&&this.remaining>0;this.remaining=this.left()+1800000;
      this.deadline=paused?null:this.now()+this.remaining;}
    toggle(){if(this.deadline!==null){this.remaining=this.left();this.deadline=null;}
      else if(this.remaining>0)this.deadline=this.now()+this.remaining;}
    reset(){this.remaining=0;this.deadline=null;}
  }
  class PlaybackClock {
    constructor(now=()=>performance.now(),schedule=setTimeout,cancel=clearTimeout){
      this.now=now;this.schedule=schedule;this.cancel=cancel;this.handle=null;this.remaining=0;this.callback=null;
    }
    start(delay,callback){this.clear();this.remaining=delay;this.callback=callback;this.resume();}
    pause(){if(this.handle!==null){this.remaining=Math.max(0,this.deadline-this.now());this.cancel(this.handle);this.handle=null;}}
    resume(){if(this.handle!==null||!this.callback)return;this.deadline=this.now()+this.remaining;
      this.handle=this.schedule(()=>{this.handle=null;this.remaining=0;const cb=this.callback;this.callback=null;cb();},this.remaining);}
    clear(){if(this.handle!==null)this.cancel(this.handle);this.handle=null;this.remaining=0;this.callback=null;}
    left(){return this.handle===null?this.remaining:Math.max(0,this.deadline-this.now());}
  }
  const api={localDateKey,replayNow,gapMs,selectedFrames,nextFrame,latestFrame,frameAtTime,WaitTimer,PlaybackClock};if(typeof module!=='undefined'&&module.exports)module.exports=api;else root.PlaybackTiming=api;
})(typeof globalThis!=='undefined'?globalThis:this);
