"""Image validation and single-image truck counting; no image persistence."""
import hashlib
import io
import re
import threading
import warnings
from pathlib import Path

from PIL import Image, ImageOps, UnidentifiedImageError


def decode_image(data, max_pixels=20_000_000):
    try:
        with warnings.catch_warnings():
            warnings.simplefilter('error', Image.DecompressionBombWarning)
            with Image.open(io.BytesIO(data)) as source:
                if source.format not in {'JPEG', 'PNG'}:
                    raise ValueError('Only JPEG and PNG images are supported')
                if source.width * source.height > max_pixels:
                    raise ValueError('Image exceeds the pixel limit')
                source.load()
                return ImageOps.exif_transpose(source).convert('RGB')
    except (UnidentifiedImageError, OSError, Image.DecompressionBombError,
            Image.DecompressionBombWarning) as exc:
        raise ValueError('Invalid, damaged, or oversized image') from exc


def canonical(value):
    return re.sub(r'[^a-z0-9]', '', value.lower())


class BusyError(Exception):
    pass


class Detector:
    def __init__(self, model, class_name, threshold, model_version, device='cpu'):
        if not 0 < threshold <= 1:
            raise ValueError('CONFIDENCE must be greater than 0 and at most 1')
        if getattr(model, 'task', None) != 'detect':
            raise ValueError('A trained object detection checkpoint is required')
        names = model.names
        entries = names.items() if isinstance(names, dict) else enumerate(names)
        matching = [(int(k), v) for k, v in entries if canonical(v) == canonical(class_name)]
        if len(matching) != 1:
            raise ValueError(f'Expected one class named {class_name!r}; model classes: {names}')
        self.class_id, self.class_name = matching[0]
        self.model, self.threshold = model, threshold
        self.version, self.device = model_version, device
        self.lock = threading.Lock()

    def predict(self, image):
        # One inference at a time per process. Do not queue unbounded work in RAM.
        if not self.lock.acquire(blocking=False):
            raise BusyError('Inference worker is busy')
        try:
            result = self.model.predict(source=image, conf=self.threshold,
                                        classes=[self.class_id], device=self.device,
                                        imgsz=640, verbose=False, save=False)[0]
            detections = []
            if result.boxes is not None:
                for xyxy, confidence, cls in zip(result.boxes.xyxy.cpu().tolist(),
                                                 result.boxes.conf.cpu().tolist(),
                                                 result.boxes.cls.cpu().tolist()):
                    if int(cls) == self.class_id and confidence >= self.threshold:
                        detections.append({'class_id': self.class_id,
                                           'class_name': self.class_name,
                                           'confidence': float(confidence),
                                           'box_xyxy': [float(x) for x in xyxy]})
            return {'truck_count': len(detections), 'detections': detections,
                    'count_scope': 'visible_trucks_in_this_image',
                    'confidence_threshold': self.threshold, 'model_version': self.version,
                    'image_width': image.width, 'image_height': image.height}
        finally:
            self.lock.release()


def load_detector(path, class_name, threshold, device):
    import os
    path = Path(path)
    if not path.is_file() or path.suffix != '.pt':
        raise ValueError('MODEL_PATH must point to your existing trusted best.pt')
    os.environ['YOLO_OFFLINE'] = 'true'
    os.environ['YOLO_CONFIG_DIR'] = '/tmp/ultralytics'
    os.environ['WANDB_MODE'] = 'disabled'
    os.environ['COMET_MODE'] = 'DISABLED'
    from ultralytics import YOLO, settings
    settings.update({k: False for k in ('sync', 'hub', 'wandb', 'comet', 'mlflow',
                                      'clearml', 'neptune', 'dvc', 'tensorboard') if k in settings})
    version = hashlib.sha256(path.read_bytes()).hexdigest()
    return Detector(YOLO(str(path)), class_name, threshold, version, device)
