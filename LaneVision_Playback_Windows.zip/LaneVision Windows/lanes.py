"""Validation and local persistence for camera-specific lane polygons."""
import json
import math
import os
import tempfile


def validate_lanes(lanes):
    if not isinstance(lanes,list) or len(lanes)>100:
        raise ValueError('Use at most 100 lanes per camera.')
    names=set()
    for lane in lanes:
        if not isinstance(lane,dict): raise ValueError('Invalid lane.')
        name=lane.get('name')
        if not isinstance(name,str) or not name.strip() or len(name)>80 or name.strip() in names:
            raise ValueError('Give every lane a unique name (up to 80 characters).')
        lane['name']=name.strip();names.add(lane['name'])
        points=lane.get('points')
        if not isinstance(points,list) or not 3<=len(points)<=100:
            raise ValueError('Each lane needs 3–100 corners.')
        for point in points:
            if not isinstance(point,list) or len(point)!=2 or any(type(v) not in (int,float) or not math.isfinite(v) or not 0<=v<=1 for v in point):
                raise ValueError('Lane corners must be inside the image.')
        if len({tuple(p) for p in points})!=len(points):raise ValueError('Remove repeated corners.')
        def cross(a,b,c):return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
        def on(a,b,p):return abs(cross(a,b,p))<1e-10 and min(a[0],b[0])-1e-10<=p[0]<=max(a[0],b[0])+1e-10 and min(a[1],b[1])-1e-10<=p[1]<=max(a[1],b[1])+1e-10
        def intersects(a,b,c,d):
            return (cross(a,b,c)*cross(a,b,d)<0 and cross(c,d,a)*cross(c,d,b)<0) or on(a,b,c) or on(a,b,d) or on(c,d,a) or on(c,d,b)
        n=len(points)
        for i in range(n):
            for j in range(i+1,n):
                if j==i+1 or (i==0 and j==n-1):continue
                if intersects(points[i],points[(i+1)%n],points[j],points[(j+1)%n]):
                    raise ValueError('Lane edges must not cross. Click corners around the perimeter.')
        area=abs(sum(points[i][0]*points[(i+1)%n][1]-points[(i+1)%n][0]*points[i][1] for i in range(n)))/2
        if area<1e-6:raise ValueError('Lane area is too small.')
    return lanes


def read_regions(path):
    if not path.exists():return {}
    data=json.loads(path.read_text())
    if not isinstance(data,dict):raise ValueError('Invalid lane regions file.')
    return data


def save_regions(path,data):
    # Replace atomically so an interruption cannot truncate an existing configuration.
    fd,name=tempfile.mkstemp(prefix='.lanes-',suffix='.tmp',dir=path.parent)
    try:
        with os.fdopen(fd,'w') as stream:
            json.dump(data,stream,indent=2,allow_nan=False);stream.write('\n')
        os.replace(name,path)
    finally:
        if os.path.exists(name):os.unlink(name)


def box_polygon_area(box,polygon):
    """Clip the polygon to the box; require positive area, not edge contact."""
    x1,y1,x2,y2=box
    if not all(math.isfinite(v) for v in box) or x2<=x1 or y2<=y1:return False
    clipped=[list(p) for p in polygon]
    for axis,bound,lower in ((0,x1,True),(0,x2,False),(1,y1,True),(1,y2,False)):
        if not clipped:return False
        output=[];previous=clipped[-1]
        def inside(p):return p[axis]>=bound if lower else p[axis]<=bound
        for point in clipped:
            if inside(point)!=inside(previous):
                fraction=(bound-previous[axis])/(point[axis]-previous[axis])
                output.append([previous[k]+fraction*(point[k]-previous[k]) for k in (0,1)])
            if inside(point):output.append(point)
            previous=point
        clipped=output
    if len(clipped)<3:return False
    area=abs(sum(p[0]*clipped[(i+1)%len(clipped)][1]-clipped[(i+1)%len(clipped)][0]*p[1] for i,p in enumerate(clipped)))/2
    return area


def box_overlaps_polygon(box,polygon):
    return box_polygon_area(box,polygon)>1e-12


def occupancy(result,lanes,total=None):
    unknown={'status':'Unknown','occupied':None,'total':total,'lanes':[]}
    if not lanes:return {**unknown,'message':'Configure lane polygons for this camera.'}
    try:validate_lanes(lanes)
    except ValueError:return {**unknown,'message':'Lane polygons are invalid.'}
    if total is None:total=len(lanes)
    if total!=len(lanes):return {**unknown,'message':'Configured lane total differs from the number of saved polygons.'}
    width,height=result.get('image_width',0),result.get('image_height',0)
    if width<=0 or height<=0:return unknown
    occupied=set();uncertain=set();assignments=[]
    for detection in result['detections']:
        x1,y1,x2,y2=detection['box_xyxy']
        box=(x1/width,y1/height,x2/width,y2/height)
        # Compare the fraction of each lane covered within the truck's horizontal
        # span, rather than raw area (which favors wide foreground lanes).
        # Lower-box overlap breaks perspective ties but cannot override a much
        # stronger full-lane match. Penalize tiny overlaps at a lane's endpoint.
        foot=(box[0],box[3]-.25*(box[3]-box[1]),box[2],box[3])
        strip=(box[0],0,box[2],1)
        scores=[]
        for lane in lanes:
            polygon=lane['points']
            local_area=box_polygon_area(strip,polygon)
            xs=[p[0] for p in polygon]
            support=max(0,min(box[2],max(xs))-max(box[0],min(xs)))/max(1e-12,box[2]-box[0])
            overlap=box_polygon_area(box,polygon)
            score=0 if local_area<=1e-12 or overlap<=1e-12 else support*(overlap+.4*box_polygon_area(foot,polygon))/local_area
            scores.append(score)
        ranking=sorted(range(len(lanes)),key=lambda i:scores[i],reverse=True)
        best=ranking[0]
        if scores[best]<=1e-12:
            assignments.append(None);continue
        contenders=[i for i in ranking if scores[i]>=scores[best]*.9]
        if len(contenders)>1:
            uncertain.update(contenders);assignments.append(None)
        else:
            occupied.add(best);assignments.append(lanes[best]['name'])
    unresolved=uncertain-occupied
    rows=[{'name':lane['name'],'points':lane['points'],
           'occupied':True if i in occupied else None if i in unresolved else False} for i,lane in enumerate(lanes)]
    return {'status':'Unknown' if unresolved else 'Full' if len(occupied)==total else 'Available',
            'occupied':None if unresolved else len(occupied),'total':total,'lanes':rows,
            'truck_lane_assignments':assignments,
            'message':'Lane assignment uncertain; amber lanes need review.' if unresolved else 'Each truck assigned to at most one lane using normalized lane overlap.'}
