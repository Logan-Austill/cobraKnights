"""Identify the code actually loaded by a server, not merely files on disk."""
import hashlib
from pathlib import Path

def fingerprint(root):
    root=Path(root)
    paths=list(root.glob('*.py'))+list((root/'static').glob('*'))
    digest=hashlib.sha256()
    for path in sorted(paths):
        if not path.is_file() or path.name.startswith('test_'):continue
        digest.update(str(path.relative_to(root)).encode());digest.update(path.read_bytes())
    return digest.hexdigest()
