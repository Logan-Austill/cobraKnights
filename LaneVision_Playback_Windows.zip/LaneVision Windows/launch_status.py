"""Authenticate the local server before opening its browser window."""
import json
import time
from urllib.request import Request, build_opener, ProxyHandler


def wait_for_server(process, url, key):
    opener = build_opener(ProxyHandler({}))
    for _ in range(100):
        if process.poll() is not None:
            raise RuntimeError('The server exited during startup.')
        try:
            request = Request(url + '/api/status', headers={'X-API-Key': key})
            with opener.open(request, timeout=1) as response:
                if json.load(response).get('app') == 'lanevision-playback-1':
                    return
        except (OSError, ValueError):
            pass
        time.sleep(.1)
    raise RuntimeError('The server did not become ready.')
