"""Windows console launcher; closing the console stops the local server."""
import os
from pathlib import Path
import secrets
import socket
import subprocess
import sys
import time
import webbrowser

from launch_status import wait_for_server

ROOT = Path(__file__).resolve().parent


def main():
    if not (ROOT / 'best.pt').is_file():
        raise RuntimeError('Put your trained best.pt beside Start LaneVision.cmd.')
    (ROOT / 'data').mkdir(exist_ok=True)
    runtime = Path(os.environ.get('LOCALAPPDATA', str(Path.home()))) / 'LaneVision Playback'
    runtime.mkdir(parents=True, exist_ok=True)
    with socket.socket() as probe:
        probe.bind(('127.0.0.1', 0))
        port = probe.getsockname()[1]
    key = secrets.token_urlsafe(32)
    url = f'http://127.0.0.1:{port}'
    command = [sys.executable, str(ROOT / 'server.py'), '--data', str(ROOT / 'data'),
               '--cache', str(runtime / 'cache'), '--port', str(port),
               '--model', str(ROOT / 'best.pt')]
    # Keep the child attached to this console so closing the window stops it.
    with (runtime / 'server.log').open('a', encoding='utf-8') as log:
        process = subprocess.Popen(command, cwd=ROOT,
                                   env=dict(os.environ, PLAYBACK_KEY=key),
                                   stdout=log, stderr=log)
        try:
            wait_for_server(process, url, key)
            webbrowser.open(url + '/#key=' + key)
            print('LaneVision is running. Keep this window open.')
            print('Close this window or press Ctrl+C to stop.')
            print('If the browser did not open, open: ' + url + '/#key=' + key)
            process.wait()
        except KeyboardInterrupt:
            pass
        finally:
            if process.poll() is None:
                process.terminate()
                try:
                    process.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    process.kill()
                    process.wait()


if __name__ == '__main__':
    try:
        main()
    except Exception as exc:
        print('Could not start LaneVision:', exc)
        print('See %LOCALAPPDATA%\\LaneVision Playback\\server.log for details.')
        sys.exit(1)
