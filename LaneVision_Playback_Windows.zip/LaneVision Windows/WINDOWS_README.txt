LaneVision for Windows 10/11 (64-bit)

1. Right-click the ZIP and choose Extract All. Open the extracted folder.
   Do not run files from inside the ZIP.
2. Install Python 3.11 (64-bit) from https://www.python.org/downloads/windows/
   Include the Python launcher during installation.
3. Double-click Setup Windows.cmd once. It installs the model libraries in a
   private .venv folder. Allow several minutes and keep internet connected.
4. Double-click Start LaneVision.cmd. Your browser opens automatically.
   Keep the console window open. Close it to stop the system.

No terminal commands need to be typed. The first setup still requires Python
and internet; this package does not contain a standalone Windows executable.

The supplied package includes the current trained best.pt, lane configuration,
and JSON metadata from the working demo. Image URLs require internet access.
Add further metadata JSON files to data/. No company API login is needed.

Replay is set in demo_config.json to November 16, 2026, using your computer's
current local time of day. Set Windows time zone to Central Time to match the
presentation. Only eligible images appear; automatic image changes wait at
least ten seconds. Previous pauses automatic updates; Refresh resumes them.
Set demo_date to null to use the actual date instead.

Lane configurations are saved per site and camera in lane_regions.json and
lane_config.json. The manual wait timer resets when the page closes.
The sign-in page is a demo and does not validate credentials.

If an image URL expires or access is denied, obtain fresh metadata URLs.
If startup fails, see the console message and
%LOCALAPPDATA%\LaneVision Playback\server.log.

Share this archive only with teammates authorized to use its model, metadata
and image URLs. Do not commit private metadata or signed URLs to a public repo.
